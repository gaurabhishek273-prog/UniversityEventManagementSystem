USE uems;

-- Verified before execution: Event.media exists and is used only by event media features.
UPDATE Event SET media = NULL WHERE media IS NOT NULL;
ALTER TABLE Event DROP COLUMN media;
