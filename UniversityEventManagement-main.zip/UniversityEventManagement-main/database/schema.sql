-- University Event Management System (UEMS) Database Schema
-- Optimized and Fixed Version

CREATE DATABASE IF NOT EXISTS uems;
USE uems;

-- ===============================
-- 1. FACULTY (Admin / Faculty)
-- ===============================
CREATE TABLE Faculty (
    Faculty_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    department VARCHAR(100),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===============================
-- 2. USERS (Students / Staff)
-- ===============================
CREATE TABLE User (
    User_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    role ENUM('student','staff') DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===============================
-- 3. VENUE
-- ===============================
CREATE TABLE Venue (
    Venue_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    location VARCHAR(200) NOT NULL,
    capacity INT,
    facilities TEXT
);

-- ===============================
-- 4. DISCOUNT SCHEME
-- ===============================
CREATE TABLE DiscountScheme (
    Scheme_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    discount_percentage DECIMAL(5,2) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===============================
-- 4. EVENT (ADMIN / FACULTY)
-- ===============================
CREATE TABLE Event (
    Event_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    venue_name VARCHAR(200) NOT NULL,
    
    coordinator_name VARCHAR(100) NOT NULL,
    coordinator_phone VARCHAR(20) NOT NULL,
    
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    
    status ENUM('planned','ongoing','completed','cancelled') DEFAULT 'planned',
    
    is_paid BOOLEAN DEFAULT FALSE,
    price DECIMAL(10,2) DEFAULT 0,
    discount_attendance DECIMAL(5,2),
    discount_exam_score DECIMAL(5,2),
    discount_amount DECIMAL(10,2),
    
    budget DECIMAL(10,2),
    sponsor VARCHAR(200),
    Faculty_id INT NOT NULL,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (Faculty_id) REFERENCES Faculty(Faculty_id) ON DELETE CASCADE
);

-- ===============================
-- 5. SUB-EVENT
-- ===============================
CREATE TABLE SubEvent (
    SubEvent_id INT AUTO_INCREMENT PRIMARY KEY,
    Event_id INT NOT NULL,
    title VARCHAR(300) NOT NULL,
    description TEXT,
    location VARCHAR(300) NOT NULL,
    
    FOREIGN KEY (Event_id) REFERENCES Event(Event_id) ON DELETE CASCADE
);

-- ===============================
-- 6. EVENT REGISTRATION
-- ===============================
CREATE TABLE Registration (
    Registration_id INT AUTO_INCREMENT PRIMARY KEY,
    User_id INT NOT NULL,
    Event_id INT NOT NULL,
    
    name VARCHAR(100) NOT NULL,
    rollNo VARCHAR(50) NOT NULL,
    branch VARCHAR(100) NOT NULL,
    mobile VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    
    attendance DECIMAL(5,2),
    exam_score DECIMAL(5,2),
    
    final_price DECIMAL(10,2) DEFAULT 0,
    discount_applied BOOLEAN DEFAULT FALSE,
    discount_amount_applied DECIMAL(10,2) DEFAULT 0,
    
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('registered','attended','cancelled') DEFAULT 'registered',
    
    FOREIGN KEY (User_id) REFERENCES User(User_id) ON DELETE CASCADE,
    FOREIGN KEY (Event_id) REFERENCES Event(Event_id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_event (User_id, Event_id)
);

-- ===============================
-- 7. EVENT FEEDBACK
-- ===============================
CREATE TABLE Feedback (
    Feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    User_id INT NOT NULL,
    Event_id INT NOT NULL,
    
    user_name VARCHAR(100),
    user_email VARCHAR(100),
    rating INT CHECK (rating BETWEEN 1 AND 5) NOT NULL,
    comments TEXT,
    
    feedback_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (User_id) REFERENCES User(User_id) ON DELETE CASCADE,
    FOREIGN KEY (Event_id) REFERENCES Event(Event_id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_feedback (User_id, Event_id)
);

-- ===============================
-- 8. SAMPLE DATA
-- ===============================
INSERT INTO Faculty (name, email, password, department, phone) VALUES
('Dr. John Smith', 'faculty@uems.edu', 'faculty123', 'Computer Science', '9876543210'),
('Admin', 'admin@uems.edu', 'admin123', 'Administration', '9876543211');

INSERT INTO User (name, email, password, phone) VALUES
('BETN1CS24004', 'BETN1CS24004@uems.edu', 'BETN1CS24004', '9876543214'),
('BETN1CS24006', 'BETN1CS24006@uems.edu', 'BETN1CS24006', '9876543216'),
('BETN1CS24023', 'BETN1CS24023@uems.edu', 'BETN1CS24023', '9876543212'),
('BETN1CS24032', 'BETN1CS24032@uems.edu', 'BETN1CS24032', '9876543215'),
('BETN1CS24033', 'BETN1CS24033@uems.edu', 'BETN1CS24033', '9876543213');

INSERT INTO DiscountScheme (name, discount_percentage, description) VALUES
('Student Discount', 20.00, 'Special discount for students'),
('Early Bird', 15.00, 'Early registration discount');

INSERT INTO Venue (name, location, capacity, facilities) VALUES
('Naad', 'Naad Auditorium', 500, 'Projector, Sound System, AC'),
('LDV 1st floor', 'LDV Building 1st Floor', 200, 'Projector, Whiteboard'),
('LDV 2nd floor', 'LDV Building 2nd Floor', 200, 'Projector, Whiteboard'),
('Sports Ground', 'Campus Sports Ground', 1000, 'Open Area, Lighting'),
('Mg 1st floor', 'MG Building 1st Floor', 150, 'Projector, Whiteboard'),
('Mg 2nd floor', 'MG Building 2nd Floor', 150, 'Projector, Whiteboard'),
('Seminar hall(Mg506)', 'MG Building Room 506', 100, 'Projector, Whiteboard'),
('LDV seminar hall', 'LDV Building Seminar Hall', 80, 'Projector, Whiteboard');
