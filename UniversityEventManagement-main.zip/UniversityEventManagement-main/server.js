const express = require('express');
const session = require('express-session');
const path = require('path');
const db = require('./config/database');

const app = express();
const PORT = 3001;

// Test database connection
db.execute('SELECT 1')
  .then(() => console.log('✅ Database connected successfully'))
  .catch(err => console.error('❌ Database connection failed:', err.message));



// Middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static('public'));
app.use(session({
  secret: 'uems-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false }
}));

// Authentication middleware
const requireAuth = (req, res, next) => {
  if (!req.session.userId) {
    return res.redirect('/');
  }
  next();
};

const requireFaculty = (req, res, next) => {
  if (!req.session.userId || req.session.userType !== 'faculty') {
    return res.status(403).json({ error: 'Faculty access required' });
  }
  next();
};

const requireStudent = (req, res, next) => {
  if (!req.session.userId || req.session.userType !== 'user') {
    return res.status(403).json({ error: 'Student login required' });
  }
  next();
};

const toLocalDatePart = (value) => {
  if (value instanceof Date) {
    const year = value.getFullYear();
    const month = String(value.getMonth() + 1).padStart(2, '0');
    const day = String(value.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  return typeof value === 'string' ? value.substring(0, 10) : '';
};

const getEventStatus = (event, now = new Date()) => {
  if (event.status === 'cancelled') return 'Cancelled';
  if (event.status === 'completed') return 'Completed';
  const startDate = toLocalDatePart(event.start_date);
  const endDate = toLocalDatePart(event.end_date || event.start_date);
  if (!startDate || !/^\d{4}-\d{2}-\d{2}$/.test(startDate)) return 'Unknown';

  const start = new Date(`${startDate}T${event.start_time || '00:00:00'}`);
  const end = new Date(`${endDate}T${event.end_time || '23:59:59'}`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return 'Unknown';
  if (now < start) return 'Upcoming';
  if (now <= end) return 'Ongoing';
  return 'Completed';
};

const formatAssistantEvent = (event) => ({
  id: event.Event_id,
  title: event.title,
  description: event.description || '',
  venue: event.venue_name,
  coordinator: event.coordinator_name,
  startDate: event.start_date,
  endDate: event.end_date,
  startTime: event.start_time,
  endTime: event.end_time,
  status: getEventStatus(event),
  category: event.category || null,
  tags: event.tags || null,
  isRegistered: Boolean(event.is_registered),
  price: event.price === null || event.price === undefined || event.price === '' ? null : Number(event.price),
  type: event.is_paid ? 'Paid' : 'Free',
  subEvents: (event.subEvents || []).map(subEvent => ({
    title: subEvent.title,
    description: subEvent.description || '',
    location: subEvent.location
  }))
});

const recommendationIntent = (message) => /recommend|recommendation|suggest|should i attend|best for me|events for me|interested in|i like|what events can i attend/.test(message.toLowerCase());

const getRecommendationTerms = (message, interests, registeredEvents) => {
  const source = [
    ...interests.map(item => item.interest),
    ...registeredEvents.map(event => `${event.title} ${event.description || ''}`),
    message
  ].join(' ').toLowerCase();
  return [...new Set(source.match(/[a-z0-9]+/g) || [])]
    .filter(term => term.length > 2 && !['the', 'and', 'for', 'events', 'event', 'show', 'some', 'with', 'what', 'should'].includes(term));
};

const scoreRecommendedEvent = (event, terms, interests, registeredEvents, message) => {
  const category = String(event.category || '').toLowerCase();
  const tags = String(event.tags || '').toLowerCase();
  const title = String(event.title || '').toLowerCase();
  const description = String(event.description || '').toLowerCase();
  const searchable = `${category} ${tags} ${title} ${description}`;
  const interestTerms = interests.flatMap(item => item.interest.toLowerCase().match(/[a-z0-9]+/g) || []);
  const registeredText = registeredEvents.map(item => `${item.title} ${item.description || ''}`.toLowerCase()).join(' ');
  let score = 2;
  const matchedTerms = [];
  terms.forEach(term => {
    if (category.includes(term)) { score += 5; matchedTerms.push(term); }
    if (tags.includes(term)) { score += 4; matchedTerms.push(term); }
    if (title.includes(term)) { score += 3; matchedTerms.push(term); }
    if (description.includes(term)) { score += 2; matchedTerms.push(term); }
    if (registeredText.includes(term) && searchable.includes(term)) { score += 3; matchedTerms.push(term); }
  });
  if (getEventStatus(event) === 'Upcoming') score += 2;
  if (/free|unpaid|no fee|without payment/.test(message.toLowerCase()) && isFreeEvent(event)) score += 1;
  return { score, matchedTerms: [...new Set(matchedTerms)] };
};

const buildRecommendations = (events, interests, registeredEvents, message) => {
  let availableEvents = events.filter(event => ['Upcoming', 'Ongoing'].includes(getEventStatus(event)) && event.status !== 'cancelled');
  if (getPriceQuery(message)) availableEvents = filterAssistantEvents(availableEvents, message);
  const terms = getRecommendationTerms(message, interests, registeredEvents);
  const topicRequested = terms.some(term => ['ai', 'machine', 'learning', 'coding', 'technical', 'technology', 'web', 'development', 'cybersecurity', 'security', 'workshop', 'hackathon'].includes(term));
  const scored = availableEvents.map(event => {
    const result = scoreRecommendedEvent(event, terms, interests, registeredEvents, message);
    return { event, ...result };
  }).filter(item => !topicRequested || item.score > 2)
    .sort((first, second) => second.score - first.score || new Date(`${first.event.start_date}T00:00:00`) - new Date(`${second.event.start_date}T00:00:00`))
    .slice(0, 5);
  return scored.map(item => ({
    ...formatAssistantEvent(item.event),
    why: item.matchedTerms.length > 0
      ? `Recommended because it matches ${item.matchedTerms.slice(0, 3).join(', ')}.`
      : 'Recommended as an upcoming event you can still attend.'
  }));
};

const getPriceQuery = (message) => {
  const lowerMessage = message.toLowerCase();
  const amounts = [...lowerMessage.matchAll(/(?:₹|rs\.?|inr\s*)\s*(\d+(?:\.\d+)?)/gi)]
    .map(match => Number(match[1]));
  const numberAfterPrice = lowerMessage.match(/(?:price|fee|cost)\D{0,12}(\d+(?:\.\d+)?)/i);
  if (numberAfterPrice && amounts.length === 0) amounts.push(Number(numberAfterPrice[1]));

  const asksFree = /\bfree\b|unpaid|no fee|without payment|zero cost|no registration fee|₹\s*0\b/.test(lowerMessage);
  const asksPaid = /\bpaid\b|payment required|registration fee|ticket price|chargeable|events with fees/.test(lowerMessage);
  const asksCheapest = /cheapest|lowest price|least expensive/.test(lowerMessage);
  const hasPriceIntent = asksFree || asksPaid || asksCheapest || amounts.length > 0 || /price|fee|cost|payment/.test(lowerMessage);
  if (!hasPriceIntent) return null;

  const isBetween = /between|from/.test(lowerMessage) && amounts.length >= 2;
  const isUnder = /under|below|less than|up to|at most/.test(lowerMessage);
  const isOver = /over|above|more than|at least/.test(lowerMessage);
  return {
    asksFree,
    asksPaid,
    asksCheapest,
    min: isBetween ? Math.min(amounts[0], amounts[1]) : (isOver ? amounts[0] : null),
    max: isBetween ? Math.max(amounts[0], amounts[1]) : (isUnder ? amounts[0] : null),
    hasNumericFilter: isBetween || isUnder || isOver
  };
};

const getEventPrice = (event) => {
  if (event.price === null || event.price === undefined || event.price === '') return null;
  const price = Number(event.price);
  return Number.isFinite(price) ? price : null;
};

const isPaidEvent = (event) => Boolean(event.is_paid) || (getEventPrice(event) !== null && getEventPrice(event) > 0);
const isFreeEvent = (event) => !isPaidEvent(event) && (getEventPrice(event) === null || getEventPrice(event) === 0);

const filterAssistantDate = (events, message) => {
  const lowerMessage = message.toLowerCase();
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  let endDate = null;
  if (lowerMessage.includes('today')) {
    endDate = new Date(today);
  } else if (lowerMessage.includes('tomorrow')) {
    endDate = new Date(today);
    endDate.setDate(endDate.getDate() + 1);
  } else if (lowerMessage.includes('this week')) {
    endDate = new Date(today);
    endDate.setDate(endDate.getDate() + 7);
  }
  if (!endDate) return events;
  return events.filter(event => {
    const eventDate = new Date(`${toLocalDatePart(event.start_date)}T00:00:00`);
    return !Number.isNaN(eventDate.getTime()) && eventDate >= today && eventDate <= endDate;
  });
};

const filterAssistantStatus = (events, message) => {
  const lowerMessage = message.toLowerCase();
  const asksCompleted = /completed|over|already happened|past events|finished/.test(lowerMessage);
  const asksUpcoming = /upcoming|still open|can i register|register for|registration available/.test(lowerMessage) || Boolean(getPriceQuery(message));
  if (asksCompleted) return events.filter(event => getEventStatus(event) === 'Completed');
  if (asksUpcoming) return events.filter(event => getEventStatus(event) === 'Upcoming');
  return events;
};

const filterAssistantTopic = (events, message) => {
  const topicTerms = ['technical', 'workshop', 'hackathon', 'seminar', 'coding', 'career', 'sports', 'cultural']
    .filter(term => message.toLowerCase().includes(term));
  if (topicTerms.length === 0) return events;
  return events.filter(event => topicTerms.some(term =>
    `${event.title} ${event.description || ''}`.toLowerCase().includes(term)
  ));
};

const filterAssistantEvents = (events, message) => {
  const priceQuery = getPriceQuery(message);
  if (!priceQuery) return events;

  let filtered = filterAssistantStatus(filterAssistantDate(events, message), message);
  if (priceQuery.asksFree) filtered = filtered.filter(isFreeEvent);
  else if (priceQuery.asksPaid) filtered = filtered.filter(isPaidEvent);
  if (priceQuery.min !== null) filtered = filtered.filter(event => getEventPrice(event) !== null && getEventPrice(event) >= priceQuery.min);
  if (priceQuery.max !== null) filtered = filtered.filter(event => getEventPrice(event) !== null && getEventPrice(event) <= priceQuery.max);
  filtered = filterAssistantTopic(filtered, message);
  if (priceQuery.asksCheapest && filtered.length > 0) {
    const cheapestPrice = Math.min(...filtered.map(getEventPrice).filter(price => price !== null));
    filtered = filtered.filter(event => getEventPrice(event) === cheapestPrice);
  }
  return filtered;
};

const formatPrice = (event) => {
  if (isFreeEvent(event)) return 'Free';
  const price = getEventPrice(event);
  return isPaidEvent(event) ? `₹${price}` : 'Pricing information is not available';
};

const buildPriceReply = (message, events) => {
  const priceQuery = getPriceQuery(message);
  if (!priceQuery) return null;
  const filteredEvents = filterAssistantEvents(events, message);
  const label = priceQuery.asksFree ? 'free' : priceQuery.asksCheapest ? 'cheapest' : 'paid';
  if (filteredEvents.length === 0) return `I couldn't find any upcoming ${label} events matching your request.`;

  const heading = priceQuery.asksFree ? 'Upcoming free events' : priceQuery.asksCheapest ? 'Cheapest upcoming events' : 'Upcoming paid events';
  const lines = filteredEvents.slice(0, 8).map((event, index) =>
    `${index + 1}. ${event.title} - ${formatPrice(event)} - ${event.start_date}, ${event.start_time} at ${event.venue_name}`
  );
  return `${heading}:\n${lines.join('\n')}\nWould you like more details about any of these events?`;
};

const buildStatusReply = (message, events) => {
  const lowerMessage = message.toLowerCase();
  const asksCompleted = /completed|over|already happened|past events|finished/.test(lowerMessage);
  const asksAvailable = !/how do i|how can i/.test(lowerMessage) && /can i register|still open|registration available|register for/.test(lowerMessage);
  if (!asksCompleted && !asksAvailable) return null;

  const matchingEvents = filterAssistantTopic(
    events.filter(event => getEventStatus(event) === (asksCompleted ? 'Completed' : 'Upcoming')),
    message
  );
  if (matchingEvents.length === 0) {
    return asksCompleted ? "I couldn't find any completed events." : "I couldn't find any events currently open for registration.";
  }
  const heading = asksCompleted ? 'Completed events' : 'Events currently open for registration';
  const lines = matchingEvents.slice(0, 8).map((event, index) =>
    `${index + 1}. ${event.title} - ${event.start_date}, ${event.start_time} at ${event.venue_name} - Status: ${getEventStatus(event)}`
  );
  return `${heading}:\n${lines.join('\n')}`;
};

const buildLocalAssistantReply = (message, events, registeredEvents) => {
  const lowerMessage = message.toLowerCase();
  const upcomingEvents = events.filter(event => getEventStatus(event) === 'Upcoming');

  const priceReply = buildPriceReply(message, events);
  if (priceReply) return priceReply;

  const statusReply = buildStatusReply(message, events);
  if (statusReply) return statusReply;

  if (lowerMessage.includes('register') && (lowerMessage.includes('how') || lowerMessage.includes('can i'))) {
    return 'To register, choose an event below and click Register. Complete the form with your details and submit it. I cannot register you directly.';
  }

  if (lowerMessage.includes('registered') || lowerMessage.includes('my event')) {
    if (registeredEvents.length === 0) return 'You are not registered for any events yet.';
    return `You are registered for: ${registeredEvents.map(event => `${event.title} (${event.start_date})`).join(', ')}.`;
  }

  const matchingEvents = upcomingEvents.filter(event =>
    `${event.title} ${event.description || ''} ${event.venue_name}`.toLowerCase()
      .split(/\s+/)
      .some(word => word.length > 3 && lowerMessage.includes(word))
  );
  const requestedEvents = matchingEvents.length > 0 ? matchingEvents :
    (lowerMessage.includes('upcoming') || lowerMessage.includes('week') || lowerMessage.includes('tomorrow') || lowerMessage.includes('today') ? upcomingEvents : []);

  if (requestedEvents.length > 0) {
    return requestedEvents.slice(0, 8).map(event =>
      `${event.title}: ${event.start_date}, ${event.start_time} at ${event.venue_name}. Organized by ${event.coordinator_name}.`
    ).join('\n');
  }

  if (lowerMessage.includes('event') || lowerMessage.includes('workshop') || lowerMessage.includes('hackathon')) {
    return upcomingEvents.length > 0
      ? `I found ${upcomingEvents.length} upcoming event${upcomingEvents.length === 1 ? '' : 's'}. Ask me for upcoming events, a venue, date, time, or a specific event name.`
      : "I couldn't find any upcoming events matching that request.";
  }

  return 'I can help with upcoming events, event details, venues, schedules, registrations, and how to register. What would you like to know?';
};

// Routes
app.post('/api/login', async (req, res) => {
  const { email, password, userType } = req.body;

  // Input validation
  if (!email || !password || !userType) {
    return res.status(400).json({ error: 'Email, password, and user type are required' });
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'Invalid email format' });
  }

  try {
    let user = null;

    if (userType === 'faculty') {
      const [rows] = await db.execute('SELECT * FROM Faculty WHERE email = ? AND password = ?', [email, password]);
      if (rows.length > 0) {
        user = rows[0];
        req.session.userId = user.Faculty_id;
        req.session.userType = 'faculty';
        req.session.userName = user.name;
      }
    } else if (userType === 'user') {
      const [rows] = await db.execute('SELECT * FROM User WHERE email = ? AND password = ?', [email, password]);
      if (rows.length > 0) {
        user = rows[0];
        req.session.userId = user.User_id;
        req.session.userType = 'user';
        req.session.userName = user.name;
      }
    } else {
      return res.status(400).json({ error: 'Invalid user type' });
    }

    if (user) {
      res.json({ success: true, userType, name: user.name });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

// Validation functions
const validateDateTime = (startDate, endDate, startTime, endTime, isUpdate = false) => {
  const start = new Date(`${startDate}T${startTime}`);
  const end = new Date(`${endDate}T${endTime}`);
  const now = new Date();

  // Skip past date validation for updates
  if (!isUpdate && start < now) return 'Event cannot be scheduled in the past';
  if (start >= end) return 'End date/time must be after start date/time';
  return null;
};

const validatePhone = (phone) => {
  if (!/^[6-9][0-9]{9}$/.test(phone)) {
    return 'Phone number must be 10 digits starting with 6-9';
  }
  return null;
};

const validateEmail = (email) => {
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return 'Invalid email format';
  }
  return null;
};

const checkVenueConflict = async (venueName, startDate, endDate, startTime, endTime, excludeEventId = null) => {
  const start = new Date(`${startDate}T${startTime}`);
  const end = new Date(`${endDate}T${endTime}`);

  let query = `
    SELECT title, start_date, end_date, start_time, end_time 
    FROM Event 
    WHERE venue_name = ? 
    AND status != 'cancelled'
    AND (
      (start_date < ? AND end_date > ?) OR
      (start_date < ? AND end_date > ?) OR
      (start_date >= ? AND start_date < ?) OR
      (start_date = ? AND start_time < ? AND end_time > ?)
    )
  `;

  let params = [
    venueName,
    end.toISOString().split('T')[0], start.toISOString().split('T')[0],
    start.toISOString().split('T')[0], end.toISOString().split('T')[0],
    start.toISOString().split('T')[0], end.toISOString().split('T')[0],
    startDate, endTime, startTime
  ];

  if (excludeEventId) {
    query += ' AND Event_id != ?';
    params.push(excludeEventId);
  }

  const [rows] = await db.execute(query, params);
  return rows.length > 0 ? rows[0] : null;
};

// Event management
app.post('/api/events', requireFaculty, async (req, res) => {
  const { title, description, start_date, end_date, start_time, end_time, venue_name, coordinator_name, coordinator_phone, budget, sponsor, is_paid, price, discount_attendance, discount_exam_score, discount_amount } = req.body;

  // Basic validation
  if (!title) return res.status(400).json({ error: 'Title is required' });
  if (!coordinator_name) return res.status(400).json({ error: 'Coordinator name is required' });
  if (!coordinator_phone) return res.status(400).json({ error: 'Coordinator phone is required' });
  if (!start_date) return res.status(400).json({ error: 'Start date is required' });
  if (!end_date) return res.status(400).json({ error: 'End date is required' });
  if (!start_time) return res.status(400).json({ error: 'Start time is required' });
  if (!end_time) return res.status(400).json({ error: 'End time is required' });
  if (!venue_name) return res.status(400).json({ error: 'Venue is required' });

  // Phone validation
  const phoneError = validatePhone(coordinator_phone);
  if (phoneError) return res.status(400).json({ error: phoneError });

  // Date/time validation
  const dateError = validateDateTime(start_date, end_date, start_time, end_time);
  if (dateError) return res.status(400).json({ error: dateError });

  // Venue conflict check
  const conflictEvent = await checkVenueConflict(venue_name, start_date, end_date, start_time, end_time);
  if (conflictEvent) {
    return res.status(400).json({
      error: `Venue '${venue_name}' is already booked for '${conflictEvent.title}' on ${conflictEvent.start_date} ${conflictEvent.start_time} - ${conflictEvent.end_time}`
    });
  }

  // Pricing validation
  if (is_paid && (!price || price <= 0)) {
    return res.status(400).json({ error: 'Price is required for paid events' });
  }

  // Discount validation
  if (discount_amount && !(discount_attendance || discount_exam_score)) {
    return res.status(400).json({ error: 'Discount criteria (attendance or exam score) required when discount amount is set' });
  }

  try {
    // Create event first
    const [result] = await db.execute(
      'INSERT INTO Event (title, description, start_date, end_date, start_time, end_time, Faculty_id, venue_name, coordinator_name, coordinator_phone, budget, sponsor, is_paid, price, discount_attendance, discount_exam_score, discount_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [title, description, start_date, end_date, start_time, end_time, req.session.userId, venue_name, coordinator_name, coordinator_phone, budget || null, sponsor || null, is_paid || false, is_paid ? parseFloat(price) : 0, discount_attendance || null, discount_exam_score || null, discount_amount || null]
    );

    const eventId = result.insertId;

    // Auto-create discount if discount details provided
    // Disabled - using Event table columns directly

    res.json({ success: true, eventId, message: 'Event created successfully!' });
  } catch (error) {
    console.error('Event creation error:', error);
    res.status(500).json({ error: `Database error: ${error.message}` });
  }
});

app.post('/api/events/:eventId/subevents', requireFaculty, async (req, res) => {
  const { eventId } = req.params;
  const { title, description, location } = req.body;

  console.log('Creating sub-event:', { eventId, title, description, location });

  try {
    const [eventRows] = await db.execute('SELECT * FROM Event WHERE Event_id = ?', [eventId]);
    if (eventRows.length === 0) {
      return res.status(404).json({ error: 'Event not found' });
    }

    const event = eventRows[0];
    const combinedTitle = `${event.title} - ${title}`;
    const combinedLocation = `${event.venue_name} - ${location}`;

    console.log('Combined values:', { combinedTitle, combinedLocation });

    await db.execute(
      'INSERT INTO SubEvent (title, description, location, Event_id) VALUES (?, ?, ?, ?)',
      [combinedTitle, description, combinedLocation, eventId]
    );

    res.json({ success: true });
  } catch (error) {
    console.error('SubEvent creation error:', error);
    res.status(500).json({ error: 'Failed to create sub-event: ' + error.message });
  }
});

app.get('/api/events', async (req, res) => {
  try {
    const [events] = await db.execute('SELECT *, DATE_FORMAT(start_date, "%Y-%m-%d") as start_date, DATE_FORMAT(end_date, "%Y-%m-%d") as end_date FROM Event ORDER BY created_at DESC');
    let registeredEventIds = new Set();
    if (req.session.userId && req.session.userType === 'user') {
      const [registrations] = await db.execute('SELECT Event_id FROM Registration WHERE User_id = ?', [req.session.userId]);
      registeredEventIds = new Set(registrations.map(registration => registration.Event_id));
    }

    // Get sub-events for each event
    for (let event of events) {
      const [subEvents] = await db.execute('SELECT * FROM SubEvent WHERE Event_id = ?', [event.Event_id]);
      event.subEvents = subEvents;

      event.computed_status = getEventStatus(event);
      event.is_registered = registeredEventIds.has(event.Event_id);
    }

    res.json(events);
  } catch (error) {
    console.error('Events loading error:', error);
    res.status(500).json({ error: 'Failed to load events' });
  }
});

app.get('/api/faculty', requireFaculty, async (req, res) => {
  try {
    const [faculty] = await db.execute('SELECT * FROM Faculty');
    res.json(faculty);
  } catch (error) {
    console.error('Faculty loading error:', error);
    res.status(500).json({ error: 'Failed to load faculty' });
  }
});

app.get('/api/venues', async (req, res) => {
  try {
    const [venues] = await db.execute('SELECT * FROM Venue');
    res.json(venues);
  } catch (error) {
    console.error('Venues loading error:', error);
    res.status(500).json({ error: 'Failed to load venues' });
  }
});

app.get('/api/discount-schemes', async (req, res) => {
  try {
    res.json([]);
  } catch (error) {
    console.error('Event discounts loading error:', error);
    res.status(500).json({ error: 'Failed to load event discounts' });
  }
});

// Discount scheme management
app.post('/api/discount-schemes', requireFaculty, async (req, res) => {
  const { name, discount_percentage, description } = req.body;

  if (!name || !discount_percentage) {
    return res.status(400).json({ error: 'Name and discount percentage are required' });
  }

  try {
    const [result] = await db.execute(
      'INSERT INTO DiscountScheme (name, discount_percentage, description) VALUES (?, ?, ?)',
      [name, parseFloat(discount_percentage), description || '']
    );

    res.json({ success: true, schemeId: result.insertId });
  } catch (error) {
    console.error('Discount scheme creation error:', error);
    res.status(500).json({ error: 'Failed to create discount scheme' });
  }
});

app.put('/api/discount-schemes/:schemeId', requireFaculty, async (req, res) => {
  const schemeId = parseInt(req.params.schemeId);
  const { name, discount_percentage, description } = req.body;

  try {
    const updateFields = [];
    const updateValues = [];

    if (name !== undefined) { updateFields.push('name = ?'); updateValues.push(name); }
    if (discount_percentage !== undefined) { updateFields.push('discount_percentage = ?'); updateValues.push(parseFloat(discount_percentage)); }
    if (description !== undefined) { updateFields.push('description = ?'); updateValues.push(description); }

    if (updateFields.length > 0) {
      updateValues.push(schemeId);
      await db.execute(`UPDATE DiscountScheme SET ${updateFields.join(', ')} WHERE Scheme_id = ?`, updateValues);
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Discount scheme update error:', error);
    res.status(500).json({ error: 'Failed to update discount scheme' });
  }
});

app.delete('/api/discount-schemes/:schemeId', requireFaculty, async (req, res) => {
  try {
    const schemeId = parseInt(req.params.schemeId);
    await db.execute('DELETE FROM DiscountScheme WHERE Scheme_id = ?', [schemeId]);
    res.json({ success: true });
  } catch (error) {
    console.error('Discount scheme deletion error:', error);
    res.status(500).json({ error: 'Failed to delete discount scheme' });
  }
});

// Admin endpoints
app.get('/api/registrations/:eventId', requireFaculty, async (req, res) => {
  try {
    const eventId = parseInt(req.params.eventId);
    const [registrations] = await db.execute('SELECT * FROM Registration WHERE Event_id = ?', [eventId]);
    res.json(registrations);
  } catch (error) {
    console.error('Registrations loading error:', error);
    res.status(500).json({ error: 'Failed to load registrations' });
  }
});

app.get('/api/feedback/:eventId', requireFaculty, async (req, res) => {
  try {
    const eventId = parseInt(req.params.eventId);
    const [feedback] = await db.execute('SELECT * FROM Feedback WHERE Event_id = ?', [eventId]);
    res.json(feedback);
  } catch (error) {
    console.error('Feedback loading error:', error);
    res.status(500).json({ error: 'Failed to load feedback' });
  }
});

app.get('/api/all-registrations', requireFaculty, async (req, res) => {
  try {
    const [registrations] = await db.execute(`
      SELECT r.*, e.title as event_title 
      FROM Registration r 
      JOIN Event e ON r.Event_id = e.Event_id 
      ORDER BY r.registration_date DESC
    `);
    res.json(registrations);
  } catch (error) {
    console.error('All registrations loading error:', error);
    res.status(500).json({ error: 'Failed to load registrations' });
  }
});

app.get('/api/download-registrations/:eventId', requireFaculty, async (req, res) => {
  try {
    const eventId = parseInt(req.params.eventId);
    const [eventRows] = await db.execute('SELECT * FROM Event WHERE Event_id = ?', [eventId]);

    if (eventRows.length === 0) {
      return res.status(404).json({ error: 'Event not found' });
    }

    const event = eventRows[0];
    const [registrations] = await db.execute('SELECT * FROM Registration WHERE Event_id = ?', [eventId]);

    if (registrations.length === 0) {
      return res.status(404).json({ error: 'No registrations found for this event' });
    }

    const registrationsWithDetails = registrations.map(reg => ({
      'Student Name': reg.name,
      'Roll Number': reg.rollNo,
      'Branch': reg.branch,
      'Mobile': reg.mobile,
      'Email': reg.email,
      'Event Title': event.title,
      'Event Date': `${event.start_date.substring(0, 10)} to ${event.end_date.substring(0, 10)}`,
      'Event Time': `${event.start_time} - ${event.end_time}`,
      'Venue': event.venue_name,
      'Coordinator': event.coordinator_name,
      'Coordinator Phone': event.coordinator_phone,
      'Budget': event.budget ? `₹${event.budget}` : 'N/A',
      'Sponsor': event.sponsor || 'N/A',
      'Event Type': event.is_paid ? `Paid (₹${event.price})` : 'Free',
      'Final Price Paid': `₹${reg.final_price || 0}`,
      'Discount Applied': reg.discount_applied ? 'Yes' : 'No',
      'Discount Amount': `₹${reg.discount_amount_applied || 0}`,
      'Attendance %': reg.attendance || 'N/A',
      'Exam Score %': reg.exam_score || 'N/A',
      'Registration Date': new Date(reg.registration_date).toLocaleDateString()
    }));

    const headers = Object.keys(registrationsWithDetails[0]);
    const csvContent = [
      headers.join(','),
      ...registrationsWithDetails.map(row =>
        headers.map(header => `"${row[header]}"`).join(',')
      )
    ].join('\n');

    const filename = `${event.title.replace(/[^a-zA-Z0-9]/g, '_')}_registrations.csv`;
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(csvContent);
  } catch (error) {
    console.error('Download error:', error);
    res.status(500).json({ error: 'Failed to generate download' });
  }
});

app.put('/api/events/:eventId', requireFaculty, async (req, res) => {
  const eventId = parseInt(req.params.eventId);
  const { title, description, start_date, end_date, start_time, end_time, venue_name, coordinator_name, coordinator_phone, budget, sponsor, status, is_paid, price, discount_attendance, discount_exam_score, discount_amount } = req.body;

  try {
    const [eventRows] = await db.execute('SELECT * FROM Event WHERE Event_id = ?', [eventId]);
    if (eventRows.length === 0) {
      return res.status(404).json({ error: 'Event not found' });
    }

    if (start_date && end_date && start_time && end_time) {
      const dateError = validateDateTime(start_date, end_date, start_time, end_time, true);
      if (dateError) {
        return res.status(400).json({ error: dateError });
      }
    }

    const updateFields = [];
    const updateValues = [];

    if (title !== undefined) { updateFields.push('title = ?'); updateValues.push(title); }
    if (description !== undefined) { updateFields.push('description = ?'); updateValues.push(description); }
    if (start_date !== undefined) { updateFields.push('start_date = ?'); updateValues.push(start_date); }
    if (end_date !== undefined) { updateFields.push('end_date = ?'); updateValues.push(end_date); }
    if (start_time !== undefined) { updateFields.push('start_time = ?'); updateValues.push(start_time); }
    if (end_time !== undefined) { updateFields.push('end_time = ?'); updateValues.push(end_time); }
    if (venue_name !== undefined) { updateFields.push('venue_name = ?'); updateValues.push(venue_name); }
    if (coordinator_name !== undefined) { updateFields.push('coordinator_name = ?'); updateValues.push(coordinator_name); }
    if (coordinator_phone !== undefined) { updateFields.push('coordinator_phone = ?'); updateValues.push(coordinator_phone); }
    if (budget !== undefined) { updateFields.push('budget = ?'); updateValues.push(budget ? parseFloat(budget) : null); }
    if (sponsor !== undefined) { updateFields.push('sponsor = ?'); updateValues.push(sponsor || null); }
    if (status !== undefined) { updateFields.push('status = ?'); updateValues.push(status); }
    if (is_paid !== undefined) {
      updateFields.push('is_paid = ?'); updateValues.push(is_paid);
      updateFields.push('price = ?'); updateValues.push(is_paid && price ? parseFloat(price) : 0);
    }
    if (discount_attendance !== undefined) { updateFields.push('discount_attendance = ?'); updateValues.push(discount_attendance ? parseFloat(discount_attendance) : null); }
    if (discount_exam_score !== undefined) { updateFields.push('discount_exam_score = ?'); updateValues.push(discount_exam_score ? parseFloat(discount_exam_score) : null); }
    if (discount_amount !== undefined) { updateFields.push('discount_amount = ?'); updateValues.push(discount_amount ? parseFloat(discount_amount) : null); }

    if (updateFields.length > 0) {
      updateValues.push(eventId);
      await db.execute(`UPDATE Event SET ${updateFields.join(', ')} WHERE Event_id = ?`, updateValues);
    }

    res.json({ success: true, message: 'Event updated successfully' });
  } catch (error) {
    console.error('Event update error:', error);
    res.status(500).json({ error: `Update failed: ${error.message}` });
  }
});

app.delete('/api/events/:eventId', requireFaculty, async (req, res) => {
  try {
    const eventId = parseInt(req.params.eventId);
    await db.execute('DELETE FROM Event WHERE Event_id = ?', [eventId]);
    res.json({ success: true });
  } catch (error) {
    console.error('Event deletion error:', error);
    res.status(500).json({ error: 'Failed to delete event' });
  }
});

app.put('/api/events/:eventId/subevents/:subEventId', requireFaculty, async (req, res) => {
  const eventId = parseInt(req.params.eventId);
  const subEventId = parseInt(req.params.subEventId);
  const { title, description, location } = req.body;

  try {
    const [eventRows] = await db.execute('SELECT * FROM Event WHERE Event_id = ?', [eventId]);
    if (eventRows.length === 0) {
      return res.status(404).json({ error: 'Event not found' });
    }

    const event = eventRows[0];
    const updateFields = [];
    const updateValues = [];

    if (title) {
      const combinedTitle = `${event.title} - ${title}`;
      updateFields.push('title = ?');
      updateValues.push(combinedTitle);
    }
    if (description !== undefined) {
      updateFields.push('description = ?');
      updateValues.push(description);
    }
    if (location) {
      const combinedLocation = `${event.venue_name} - ${location}`;
      updateFields.push('location = ?');
      updateValues.push(combinedLocation);
    }

    if (updateFields.length > 0) {
      updateValues.push(subEventId);
      await db.execute(`UPDATE SubEvent SET ${updateFields.join(', ')} WHERE SubEvent_id = ?`, updateValues);
    }

    res.json({ success: true });
  } catch (error) {
    console.error('SubEvent update error:', error);
    res.status(500).json({ error: 'Failed to update sub-event' });
  }
});

app.delete('/api/events/:eventId/subevents/:subEventId', requireFaculty, async (req, res) => {
  try {
    const subEventId = parseInt(req.params.subEventId);
    await db.execute('DELETE FROM SubEvent WHERE SubEvent_id = ?', [subEventId]);
    res.json({ success: true });
  } catch (error) {
    console.error('SubEvent deletion error:', error);
    res.status(500).json({ error: 'Failed to delete sub-event' });
  }
});

// Student event assistant
app.post('/api/student/chat', requireStudent, async (req, res) => {
  const message = typeof req.body.message === 'string' ? req.body.message.trim() : '';

  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }
  if (message.length > 1000) {
    return res.status(400).json({ error: 'Message is too long' });
  }

  try {
    const priceQuery = getPriceQuery(message);
    const eventConditions = ["status != 'cancelled'"];
    const eventParams = [];
    if (priceQuery?.asksFree) {
      eventConditions.push('(is_paid = 0 AND (price IS NULL OR price = 0))');
    } else if (priceQuery?.asksPaid) {
      eventConditions.push('(is_paid = 1 OR price > 0)');
    }
    if (priceQuery && priceQuery.min !== null && priceQuery.min !== undefined) {
      eventConditions.push('price >= ?');
      eventParams.push(priceQuery.min);
    }
    if (priceQuery && priceQuery.max !== null && priceQuery.max !== undefined) {
      eventConditions.push('price <= ?');
      eventParams.push(priceQuery.max);
    }
    const lowerMessage = message.toLowerCase();
    if (priceQuery && lowerMessage.includes('today')) {
      eventConditions.push('start_date = CURDATE()');
    } else if (priceQuery && lowerMessage.includes('tomorrow')) {
      eventConditions.push('start_date = DATE_ADD(CURDATE(), INTERVAL 1 DAY)');
    } else if (priceQuery && lowerMessage.includes('this week')) {
      eventConditions.push('start_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)');
    }

    const [events] = await db.execute(`
      SELECT Event_id, title, description, venue_name, coordinator_name,
             DATE_FORMAT(start_date, '%Y-%m-%d') AS start_date,
             DATE_FORMAT(end_date, '%Y-%m-%d') AS end_date,
             start_time, end_time, status, is_paid, price, category, tags
      FROM Event
      WHERE ${eventConditions.join(' AND ')}
      ORDER BY start_date ASC, start_time ASC
    `, eventParams);
    const eventIds = events.map(event => event.Event_id);
    const [subEvents] = eventIds.length > 0
      ? await db.execute(
        `SELECT Event_id, title, description, location FROM SubEvent WHERE Event_id IN (${eventIds.map(() => '?').join(',')})`,
        eventIds
      )
      : [[]];
    const [registeredEvents] = await db.execute(`
            SELECT e.Event_id, e.title, e.description, DATE_FORMAT(e.start_date, '%Y-%m-%d') AS start_date,
              e.start_time, e.venue_name, r.status
      FROM Registration r
      JOIN Event e ON e.Event_id = r.Event_id
      WHERE r.User_id = ? AND e.status != 'cancelled'
      ORDER BY e.start_date ASC, e.start_time ASC
    `, [req.session.userId]);
    const [interests] = await db.execute(
      'SELECT interest FROM UserInterest WHERE User_id = ? ORDER BY created_at DESC',
      [req.session.userId]
    );

    const eventsWithSubEvents = events.map(event => ({
      ...event,
      is_registered: registeredEvents.some(registration => registration.Event_id === event.Event_id),
      subEvents: subEvents.filter(subEvent => subEvent.Event_id === event.Event_id)
    }));
    const recommendations = recommendationIntent(message)
      ? buildRecommendations(eventsWithSubEvents, interests, registeredEvents, message)
      : [];
    const relevantEvents = getPriceQuery(message) ? filterAssistantEvents(eventsWithSubEvents, message) : eventsWithSubEvents;
    const safeEvents = recommendations.length > 0
      ? recommendations
      : relevantEvents.map(formatAssistantEvent);
    const safeRegisteredEvents = registeredEvents.map(event => ({
      id: event.Event_id,
      title: event.title,
      startDate: event.start_date,
      startTime: event.start_time,
      venue: event.venue_name,
      status: event.status
    }));

    if (!process.env.OPENAI_API_KEY) {
      return res.json({
        reply: recommendations.length > 0
          ? 'Based on your interests and event activity, here are some events you may like:'
          : buildLocalAssistantReply(message, events, registeredEvents),
        recommendations
      });
    }

    const aiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        temperature: 0.2,
        max_tokens: 500,
        messages: [
          {
            role: 'system',
            content: 'You are an AI Event Assistant inside an Event Management System. Help students with questions related to events, registrations, schedules, venues, and the event management platform. Use the provided system data as the source of truth. Never invent event names, dates, locations, registrations, statuses, recommendations, or other system information. For recommendation questions, use only the supplied scored recommendations and explain the supplied why text. Never recommend Completed, Cancelled, or Unknown events. Use each event computed status: Upcoming, Ongoing, Completed, Cancelled, or Unknown. Only Upcoming events are open for registration in this system; registration deadlines and capacity are unavailable unless present in the data. If the required information is not available, clearly say that you do not have that information. Keep answers clear, concise, and student-friendly. Event categories, registration deadlines, capacity, and speaker information are unavailable unless present in the data.'
          },
          {
            role: 'user',
            content: JSON.stringify({ question: message, events: safeEvents, registeredEvents: safeRegisteredEvents })
          }
        ]
      })
    });

    if (!aiResponse.ok) {
      throw new Error(`AI service returned ${aiResponse.status}`);
    }
    const aiData = await aiResponse.json();
    const reply = aiData.choices?.[0]?.message?.content?.trim();
    if (!reply) throw new Error('AI service returned an empty response');
    res.json({ reply, recommendations });
  } catch (error) {
    console.error('Student assistant error:', error.message);
    res.status(503).json({ error: "Sorry, I'm having trouble responding right now. Please try again in a moment." });
  }
});

// User registration for events
app.post('/api/register/:eventId', async (req, res) => {
  try {
    if (!req.session.userId || req.session.userType !== 'user') {
      return res.status(403).json({ error: 'User login required' });
    }

    const eventId = Number.parseInt(req.params.eventId, 10);
    const { name, rollNo, branch, mobile, email, attendance, exam_score } = req.body;

    if (!Number.isInteger(eventId) || eventId <= 0) {
      return res.status(400).json({ error: 'Invalid event' });
    }

    const [userRows] = await db.execute('SELECT User_id FROM User WHERE User_id = ?', [req.session.userId]);
    if (userRows.length === 0) {
      return res.status(403).json({ error: 'Student account not found' });
    }

    const [eventRows] = await db.execute('SELECT * FROM Event WHERE Event_id = ?', [eventId]);
    if (eventRows.length === 0) {
      return res.status(404).json({ error: 'Event not found' });
    }

    const event = eventRows[0];
    if (event.status === 'cancelled') {
      return res.status(400).json({ error: 'This event is cancelled. Registration is not available.' });
    }

    const eventStatus = getEventStatus(event);
    if (eventStatus === 'Completed') {
      return res.status(400).json({ error: 'This event has already been completed. Registration is no longer available.' });
    }
    if (eventStatus === 'Ongoing') {
      return res.status(400).json({ error: 'This event has already started. Registration is no longer available.' });
    }
    if (eventStatus === 'Unknown') {
      return res.status(400).json({ error: 'This event has invalid date information. Registration is unavailable.' });
    }

    // Required fields validation
    if (!name || !rollNo || !branch || !mobile || !email) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Name validation
    if (name.length < 2 || name.length > 50 || !/^[A-Za-z\s.''-]+$/.test(name)) {
      return res.status(400).json({ error: 'Invalid name format (2-50 characters, letters only)' });
    }

    // Roll number validation - more flexible pattern
    if (!/^[A-Za-z0-9]{4,15}$/.test(rollNo)) {
      return res.status(400).json({ error: 'Invalid roll number format (4-15 alphanumeric characters)' });
    }

    // Phone validation
    const phoneError = validatePhone(mobile);
    if (phoneError) return res.status(400).json({ error: phoneError });

    // Email validation
    const emailError = validateEmail(email);
    if (emailError) return res.status(400).json({ error: emailError });

    // Check for duplicate registration after event availability checks.
    const [existing] = await db.execute('SELECT * FROM Registration WHERE User_id = ? AND Event_id = ?', [req.session.userId, eventId]);
    if (existing.length > 0) {
      return res.status(400).json({ error: 'You are already registered for this event.' });
    }

    // Calculate discount
    let finalPrice = event.price || 0;
    let discountApplied = false;
    let discountAmountApplied = 0;

    if (event.is_paid && (event.discount_attendance || event.discount_exam_score) && event.discount_amount) {
      const attendanceQualifies = event.discount_attendance && attendance >= event.discount_attendance;
      const examQualifies = event.discount_exam_score && exam_score >= event.discount_exam_score;

      if (attendanceQualifies || examQualifies) {
        discountAmountApplied = event.discount_amount;
        finalPrice = Math.max(0, finalPrice - discountAmountApplied);
        discountApplied = true;
      }
    }

    await db.execute(
      'INSERT INTO Registration (User_id, Event_id, name, rollNo, branch, mobile, email, attendance, exam_score, final_price, discount_applied, discount_amount_applied) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [req.session.userId, eventId, name, rollNo, branch, mobile, email, attendance || null, exam_score || null, finalPrice, discountApplied, discountAmountApplied]
    );

    res.json({
      success: true,
      message: 'Registration successful!',
      finalPrice,
      discountApplied: discountApplied ? `₹${discountAmountApplied} discount applied` : 'No discount applied'
    });
  } catch (error) {
    console.error('Registration error:', error);
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ error: 'You are already registered for this event.' });
    }
    res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});

// Feedback
app.post('/api/feedback/:eventId', async (req, res) => {
  try {
    if (!req.session.userId || req.session.userType !== 'user') {
      return res.status(403).json({ error: 'User login required' });
    }

    const eventId = parseInt(req.params.eventId);
    const userId = req.session.userId;
    const { rating, comments } = req.body;

    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'Valid rating (1-5) is required' });
    }

    const [userRows] = await db.execute('SELECT * FROM User WHERE User_id = ?', [userId]);
    if (userRows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = userRows[0];

    // Remove existing feedback if any
    await db.execute('DELETE FROM Feedback WHERE User_id = ? AND Event_id = ?', [userId, eventId]);

    await db.execute(
      'INSERT INTO Feedback (User_id, Event_id, user_name, user_email, rating, comments) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, eventId, user.name, user.email, rating, comments || '']
    );

    res.json({ success: true, message: 'Feedback submitted!' });
  } catch (error) {
    console.error('Feedback error:', error);
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ error: 'Feedback already submitted for this event' });
    }
    res.status(500).json({ error: 'Failed to submit feedback. Please try again.' });
  }
});

// Serve HTML pages
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/faculty', requireAuth, (req, res) => {
  if (req.session.userType !== 'faculty') {
    return res.redirect('/user');
  }
  res.sendFile(path.join(__dirname, 'public', 'faculty.html'));
});

app.get('/user', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'user.html'));
});

app.get('/admin', requireAuth, (req, res) => {
  if (req.session.userType !== 'faculty') {
    return res.redirect('/user');
  }
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.listen(PORT, () => {
  console.log(`UEMS Server running on http://localhost:${PORT}`);
  console.log('\n=== Database Setup Required ===');
  console.log('1. Install MySQL and create database:');
  console.log('   mysql -u root -p');
  console.log('   CREATE DATABASE uems;');
  console.log('2. Import schema:');
  console.log('   mysql -u root -p uems < database/schema.sql');
  console.log('3. Update database password in config/database.js');
  console.log('\nDemo Accounts:');
  console.log('Faculty: faculty@uems.edu / faculty123');
  console.log('Admin: admin@uems.edu / admin123');
  console.log('Students:');
  console.log('  BETN1CS24023@uems.edu / BETN1CS24023');
  console.log('  BETN1CS24033@uems.edu / BETN1CS24033');
  console.log('  BETN1CS24004@uems.edu / BETN1CS24004');
  console.log('  BETN1CS24032@uems.edu / BETN1CS24032');
  console.log('  BETN1CS24006@uems.edu / BETN1CS24006');
});