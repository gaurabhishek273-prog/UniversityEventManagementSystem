(() => {
    const suggestions = [
        'What events are upcoming?',
        'What events have I registered for?',
        'Recommend events for me',
        'How do I register for an event?'
    ];

    const style = document.createElement('style');
    style.textContent = `
        .event-assistant-launcher {
            position: fixed;
            right: 24px;
            bottom: 24px;
            z-index: 1000;
            width: 54px;
            height: 54px;
            border: 0;
            border-radius: 50%;
            background: #007bff;
            color: white;
            font-size: 25px;
            line-height: 1;
            cursor: pointer;
            box-shadow: 0 4px 14px rgba(0, 86, 179, .3);
            transition: transform .2s ease, background .2s ease;
        }
        .event-assistant-launcher:hover { background: #0056b3; transform: translateY(-2px); }
        .event-assistant-window {
            position: fixed;
            right: 24px;
            bottom: 90px;
            z-index: 1000;
            display: flex;
            flex-direction: column;
            width: min(380px, calc(100vw - 32px));
            height: min(560px, calc(100vh - 120px));
            overflow: hidden;
            background: white;
            border: 1px solid #d9e2ec;
            border-radius: 12px;
            box-shadow: 0 10px 35px rgba(0, 0, 0, .18);
            opacity: 0;
            pointer-events: none;
            transform: translateY(12px) scale(.98);
            transition: opacity .2s ease, transform .2s ease;
        }
        .event-assistant-window.is-open { opacity: 1; pointer-events: auto; transform: translateY(0) scale(1); }
        .event-assistant-header {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 15px 16px;
            background: #007bff;
            color: white;
        }
        .event-assistant-header-icon { font-size: 20px; }
        .event-assistant-heading { flex: 1; }
        .event-assistant-heading strong, .event-assistant-heading small { display: block; }
        .event-assistant-heading small { margin-top: 2px; opacity: .85; }
        .event-assistant-close {
            border: 0;
            background: transparent;
            color: white;
            font-size: 24px;
            line-height: 1;
            cursor: pointer;
        }
        .event-assistant-messages {
            flex: 1;
            overflow-y: auto;
            padding: 16px;
            background: #f5f7fa;
        }
        .event-assistant-message {
            max-width: 84%;
            margin: 0 0 10px;
            padding: 10px 12px;
            border-radius: 12px;
            white-space: pre-line;
            word-wrap: break-word;
            font-size: 14px;
            line-height: 1.45;
        }
        .event-assistant-message.assistant { margin-right: auto; background: white; color: #263238; border: 1px solid #e0e6ed; border-bottom-left-radius: 4px; }
        .event-assistant-message.user { margin-left: auto; background: #007bff; color: white; border-bottom-right-radius: 4px; }
        .event-assistant-suggestions { display: flex; flex-wrap: wrap; gap: 7px; margin: 2px 0 14px; }
        .event-assistant-suggestion {
            padding: 7px 9px;
            border: 1px solid #007bff;
            border-radius: 14px;
            background: white;
            color: #0056b3;
            font-size: 12px;
            cursor: pointer;
        }
        .event-assistant-suggestion:hover { background: #eaf3ff; }
        .event-assistant-typing { color: #667788; font-style: italic; }
        .event-assistant-input-area { display: flex; gap: 8px; padding: 12px; border-top: 1px solid #e0e6ed; background: white; }
        .event-assistant-input {
            min-width: 0;
            flex: 1;
            padding: 10px 11px;
            border: 1px solid #c9d3df;
            border-radius: 6px;
            font: inherit;
        }
        .event-assistant-send { padding: 10px 14px; border: 0; border-radius: 6px; background: #007bff; color: white; cursor: pointer; }
        .event-assistant-send:disabled { background: #aab7c4; cursor: not-allowed; }
        .event-assistant-recommendations { display: grid; gap: 9px; margin: 4px 0 14px; }
        .event-assistant-card { padding: 11px; background: white; border: 1px solid #d9e2ec; border-radius: 8px; color: #263238; font-size: 12px; line-height: 1.45; }
        .event-assistant-card strong { display: block; color: #0056b3; font-size: 14px; margin-bottom: 4px; }
        .event-assistant-card span { display: block; }
        .event-assistant-card p { margin: 5px 0; color: #526579; }
        .event-assistant-card button { padding: 6px 9px; border: 0; border-radius: 5px; background: #007bff; color: white; cursor: pointer; font-size: 12px; }
        .event-assistant-card button:disabled { background: #aab7c4; cursor: not-allowed; }
        @media (max-width: 480px) {
            .event-assistant-launcher { right: 16px; bottom: 16px; }
            .event-assistant-window { right: 16px; bottom: 82px; width: calc(100vw - 32px); height: min(600px, calc(100vh - 104px)); }
        }
    `;
    document.head.appendChild(style);

    const launcher = document.createElement('button');
    launcher.className = 'event-assistant-launcher';
    launcher.type = 'button';
    launcher.title = 'Open Event Assistant';
    launcher.setAttribute('aria-label', 'Open Event Assistant');
    launcher.textContent = '\u{1F4AC}';

    const chatWindow = document.createElement('section');
    chatWindow.className = 'event-assistant-window';
    chatWindow.setAttribute('aria-label', 'Event Assistant chat');
    chatWindow.innerHTML = `
        <header class="event-assistant-header">
            <span class="event-assistant-header-icon">\u{1F4AC}</span>
            <div class="event-assistant-heading"><strong>Event Assistant</strong><small>Online</small></div>
            <button type="button" class="event-assistant-close" title="Close Event Assistant" aria-label="Close Event Assistant">&times;</button>
        </header>
        <div class="event-assistant-messages" aria-live="polite"></div>
        <form class="event-assistant-input-area">
            <input class="event-assistant-input" type="text" maxlength="1000" placeholder="Ask about events..." aria-label="Message">
            <button class="event-assistant-send" type="submit">Send</button>
        </form>
    `;
    document.body.append(launcher, chatWindow);

    const messages = chatWindow.querySelector('.event-assistant-messages');
    const form = chatWindow.querySelector('form');
    const input = chatWindow.querySelector('input');
    const sendButton = chatWindow.querySelector('.event-assistant-send');
    let isLoading = false;

    const scrollToLatest = () => { messages.scrollTop = messages.scrollHeight; };
    const updateSendButton = () => { sendButton.disabled = isLoading || !input.value.trim(); };
    const addMessage = (text, role) => {
        const message = document.createElement('div');
        message.className = `event-assistant-message ${role}`;
        message.textContent = text;
        messages.appendChild(message);
        scrollToLatest();
    };
    const addRecommendations = (recommendations) => {
        if (!Array.isArray(recommendations) || recommendations.length === 0) return;
        const container = document.createElement('div');
        container.className = 'event-assistant-recommendations';
        recommendations.forEach(event => {
            const card = document.createElement('article');
            card.className = 'event-assistant-card';
            const price = event.type === 'Free' ? 'Free' : event.price === null ? 'Pricing unavailable' : `Paid - ₹${event.price}`;
            card.innerHTML = `<strong></strong><span></span><span></span><span></span><span></span><span></span><span></span><p></p><button type="button"></button>`;
            card.querySelector('strong').textContent = `Event: ${event.title}`;
            card.querySelectorAll('span')[0].textContent = `Date: ${event.startDate} to ${event.endDate}`;
            card.querySelectorAll('span')[1].textContent = `Time: ${event.startTime} to ${event.endTime}`;
            card.querySelectorAll('span')[2].textContent = `Venue: ${event.venue || 'Not specified'}`;
            card.querySelectorAll('span')[3].textContent = `Status: ${event.status}`;
            card.querySelectorAll('span')[4].textContent = `Category: ${event.category || 'Not specified'}`;
            card.querySelectorAll('span')[5].textContent = `Tags: ${event.tags || 'Not specified'}`;
            card.querySelector('p').textContent = `Type: ${price}. ${event.why}`;
            const action = card.querySelector('button');
            const unavailable = event.isRegistered || event.status !== 'Upcoming';
            action.textContent = event.isRegistered ? 'Already Registered' : event.status === 'Completed' ? 'Completed' : event.status === 'Cancelled' ? 'Cancelled' : event.status === 'Ongoing' ? 'Registration Closed' : 'Register Now';
            action.disabled = unavailable;
            if (!unavailable) action.addEventListener('click', () => window.showRegistrationForm(event.id));
            container.appendChild(card);
        });
        messages.appendChild(container);
        scrollToLatest();
    };
    const setLoading = (loading) => {
        isLoading = loading;
        input.disabled = loading;
        updateSendButton();
        const typing = messages.querySelector('.event-assistant-typing');
        if (loading && !typing) {
            const indicator = document.createElement('div');
            indicator.className = 'event-assistant-message assistant event-assistant-typing';
            indicator.textContent = 'Thinking...';
            messages.appendChild(indicator);
        } else if (!loading && typing) {
            typing.remove();
        }
        scrollToLatest();
    };
    const sendMessage = async (text) => {
        const message = text.trim();
        if (!message || isLoading) return;
        addMessage(message, 'user');
        input.value = '';
        setLoading(true);
        try {
            const response = await fetch('/api/student/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message })
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || 'Unable to respond');
            addMessage(data.reply, 'assistant');
            addRecommendations(data.recommendations);
        } catch (error) {
            addMessage(error.message === 'Failed to fetch' ? 'Network error. Please try again.' : error.message, 'assistant');
        } finally {
            setLoading(false);
            input.focus();
        }
    };

    const suggestionBox = document.createElement('div');
    suggestionBox.className = 'event-assistant-suggestions';
    suggestions.forEach(question => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'event-assistant-suggestion';
        button.textContent = question;
        button.addEventListener('click', () => sendMessage(question));
        suggestionBox.appendChild(button);
    });
    addMessage('Hi! I am your Event Assistant. I can help you discover events, check event details, registration information, schedules, and more. What would you like to know?', 'assistant');
    messages.appendChild(suggestionBox);

    launcher.addEventListener('click', () => {
        const isOpen = chatWindow.classList.toggle('is-open');
        launcher.title = isOpen ? 'Close Event Assistant' : 'Open Event Assistant';
        launcher.setAttribute('aria-label', launcher.title);
        if (isOpen) input.focus();
    });
    chatWindow.querySelector('.event-assistant-close').addEventListener('click', () => {
        chatWindow.classList.remove('is-open');
        launcher.title = 'Open Event Assistant';
        launcher.setAttribute('aria-label', launcher.title);
    });
    form.addEventListener('submit', event => {
        event.preventDefault();
        sendMessage(input.value);
    });
    input.addEventListener('input', updateSendButton);
    updateSendButton();
})();
