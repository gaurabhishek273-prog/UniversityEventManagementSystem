// Test script to verify SubEvent functionality
const db = require('./config/database');

async function testSubEvent() {
  try {
    // Get an existing event
    const [events] = await db.execute('SELECT * FROM Event LIMIT 1');
    if (events.length === 0) {
      console.log('No events found. Create an event first.');
      return;
    }
    
    const event = events[0];
    console.log('Parent Event:', event.title, 'at', event.venue_name);
    
    // Test data
    const subEventTitle = 'Dance Competition';
    const subEventLocation = 'Main Stage';
    const combinedTitle = `${event.title} - ${subEventTitle}`;
    const combinedLocation = `${event.venue_name} - ${subEventLocation}`;
    
    console.log('Expected Combined Title:', combinedTitle);
    console.log('Expected Combined Location:', combinedLocation);
    
    // Insert test sub-event
    await db.execute(
      'INSERT INTO SubEvent (title, description, location, Event_id) VALUES (?, ?, ?, ?)',
      [combinedTitle, 'Test sub-event', combinedLocation, event.Event_id]
    );
    
    console.log('✅ SubEvent created successfully with combined format');
    
    // Verify the data
    const [subEvents] = await db.execute('SELECT * FROM SubEvent WHERE Event_id = ?', [event.Event_id]);
    console.log('SubEvents in database:');
    subEvents.forEach(sub => {
      console.log(`- ID: ${sub.SubEvent_id}, Title: "${sub.title}", Location: "${sub.location}"`);
    });
    
  } catch (error) {
    console.error('Test failed:', error.message);
  } finally {
    process.exit();
  }
}

testSubEvent();